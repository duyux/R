[![Build Status](https://travis-ci.org/MariekeDirk/Temperature.svg?branch=master)](https://travis-ci.org/MariekeDirk/Temperature)

# Interpolation methods for temperature
This package contains the interpolation methods used for the [GeoMla proceeding on page 56](http://geomla.grf.bg.ac.rs/site_media/static/Proceedings%20of%20GeoMla%202016%20Conference.pdf). 

# Data sets 
The functions have been used for temperature analysis for the period 1995 until 2014, using harmonie reanalysis and ground based observations
