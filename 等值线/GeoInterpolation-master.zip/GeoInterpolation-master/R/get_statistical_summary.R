#'
#'@title Statistics from interpolation
#'@param residual difference between the observed and predicted value
#'@param observed observation from your groundstations
#'@param prediction prediction using the interpolation at the location of the groundstations
#'@description makes a statistical summary list from the output of interpolation kriging
#'@details look at \code{interpolation_kriging}
#'@author Marieke Dirksen
#'@export

#######main directories##############
# filesdir="E:\\Temperature_interpolation\\output_CrossValidation"
# filesdir_HARMONIE<-"E:\\R_scripts_HARMONIE\\output_HARMONIE_CV"

get_statistical_summary<-function(residual,observed,prediction){

n<-length(prediction)
#r2
teller<-sum(residual^2)
noemer<-sum((observed-mean(observed))^2)
r2<-1-teller/noemer

#rmse
RMSE<-sqrt(n*(sum(prediction)-sum(observed))^2)
RMSEsd<-RMSE/sqrt(1/length(noemer)*sum(noemer))

#ME
ME<-n*(sum(prediction)-sum(observed))
MEmean<-ME/mean(observed)

return(list("R2"=r2,"RMSE"=RMSE,"RMSEsd"=RMSEsd,"ME"=ME,"MEmean"=MEmean))
}