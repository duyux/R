library(shiny)

shinyUI(

  fluidPage(
    titlePanel("Temperature Interpolation"),
    
    sidebarLayout(
      sidebarPanel(
        sliderInput("blocksize",
                    "blocksize:",
                    min = 10000,
                    max = 70000,
                    value = 20000),
        selectInput("variogram","variogram model",c("Exp","Sph","Gau")),
        dateInput("t","Date",min="1995/01/02",max="2014/06/29",value="1999/01/19")
      ),
    
    # 
    # sidebarLayout(
    #   sidebarPanel(
    #     sliderInput("blocksize","blocksize",min=as.numeric(10000),
    #                 max=as.numeric(70000),value=as.numeric(20000),step=1000)
    #   ),
      
      mainPanel(
      plotOutput("plotKrige"),
      
      tableOutput("statistics")
    )
  ))
)

  #
  # # Application title
  # headerPanel("Temperature Interpolation"),
  #
  # # Sidebar with controls to select the variable to plot against mpg
  # # and to specify whether outliers should be included
  # sidebarPanel(
  # sliderInput("blocksize","blocksize",min=as.numeric(10000),max=as.numeric(70000),value=as.numeric(20000),step=1000),
  # 
  #
  #
  #   # dateRangeInput("daterange1","Date range:",
  #   # start = "1995/01/02",
  #   # end ="2014/06/29")
  #   # checkboxInput("outliers", "Show outliers", FALSE)
  # ),
  #
  # # Show the caption and plot of the requested variable against mpg


