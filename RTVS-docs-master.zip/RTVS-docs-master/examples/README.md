### RTVS examples

Here are two sets of examples to get you started with R Tools 
for Visual Studio.

**A First Look at R** shows you how to open and run an R script in
the interactive terminal.

**MRS and Machine Learning** shows you how to use R and Microsoft R Server
to create machine learning models and handle large data sets.

The README files in each directory give more detail about each example.
